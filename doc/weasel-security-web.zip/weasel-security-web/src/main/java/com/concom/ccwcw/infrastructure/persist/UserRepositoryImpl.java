package com.concom.ccwcw.infrastructure.persist;

import org.springframework.stereotype.Repository;

import com.weasel.mybatis.MybatisOperations;
import com.weasel.security.domain.user.User;
import com.weasel.security.domain.user.UserRepository;

@Repository
public class UserRepositoryImpl extends MybatisOperations<Integer, User>implements UserRepository {
	

	@Override
	public User getByUsername(String username) {
		return getSqlSession().selectOne(getNamespace().concat(".getByUsername"), username);
	}

	@Override
	public void LockUser(User user) {
		getSqlSession().update(getNamespace().concat(".lockUser"), user);
	}

}
