package com.concom.ccwcw.infrastructure.exception;

public final class HttpStatusCodeExceptionHolder {
	private HttpStatusCodeExceptionHolder() {
	}

	public static final BadRequestException BAD_REQUEST_EXCEPTION = new BadRequestException();
	public static final IllegalRequestException ILLEGAL_REQUEST_EXCEPTION = new IllegalRequestException();
	public static final NotFoundException NOT_FOUND_EXCEPTION = new NotFoundException();
	public static final InternalServerErrorException INTERNAL_SERVER_ERROR_EXCEPTION = new InternalServerErrorException();
	public static final RuntimeException RUNTIME_EXECPTION = new RuntimeException();
}
