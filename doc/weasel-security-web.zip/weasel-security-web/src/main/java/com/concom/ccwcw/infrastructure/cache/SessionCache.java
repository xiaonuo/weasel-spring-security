package com.concom.ccwcw.infrastructure.cache;

import java.util.Set;

import org.springframework.stereotype.Repository;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.weasel.security.infrastructure.shiro.cache.repository.CacheRepository;

@Repository
@SuppressWarnings("unchecked")
public class SessionCache implements CacheRepository {
	
	private Cache<String,Object> cache = CacheBuilder.newBuilder().maximumSize(10000).build();

	@Override
	public <T> T get(String key) {
		return (T)cache.getIfPresent(key);
	}

	@Override
	public <T> void save(String key, T entity) {
		cache.put(key, entity);
	}

	@Override
	public void remove(String key) {
		cache.invalidate(key);
	}

	@Override
	public Set<String> keys() {
		return cache.asMap().keySet();
	}

}
