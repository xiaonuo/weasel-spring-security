package com.concom.ccwcw.interfaces.controller.test;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.weasel.security.domain.user.User;
import com.weasel.security.infrastructure.helper.ShiroSecurityHelper;
import com.weasel.security.interfaces.SecurityServer;

/**
 * @author Dylan
 * @time 2013-11-13
 */
@Controller
public class UserController{
	
	@Autowired
	private SecurityServer securityServer;
	

	@RequestMapping(value = "/login.html", method = RequestMethod.GET)
	public String login(@ModelAttribute User user) {
		
		return "login";
	}
	
	
	@RequestMapping(value = "/login.html", method = RequestMethod.POST)
	public String login(User user,HttpServletRequest request,HttpServletResponse response) {
		
		securityServer.login(user, request, response);
		
		user = ShiroSecurityHelper.getCurrentUser();
		System.out.println(user.getUsername() + " : " + ShiroSecurityHelper.hasAuthenticated());
		
		return "index";
	}
	

	
}
