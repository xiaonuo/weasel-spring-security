/*
Navicat MySQL Data Transfer

Source Server         : 172.16.0.36
Source Server Version : 50145
Source Host           : 172.16.0.36:3308
Source Database       : costexpressdb

Target Server Type    : MYSQL
Target Server Version : 50145
File Encoding         : 65001

Date: 2014-03-18 10:18:00
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for tAuthCode
-- ----------------------------
DROP TABLE IF EXISTS `tAuthCode`;
CREATE TABLE `tAuthCode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(6) NOT NULL,
  `name` varchar(50) NOT NULL
  PRIMARY KEY (`id`),
  UNIQUE KEY `IX_tAuthCode` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=171544 DEFAULT CHARSET=utf8;
