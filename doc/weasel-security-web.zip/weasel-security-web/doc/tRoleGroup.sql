/*
Navicat MySQL Data Transfer

Source Server         : 172.16.0.36
Source Server Version : 50145
Source Host           : 172.16.0.36:3308
Source Database       : costexpressdb

Target Server Type    : MYSQL
Target Server Version : 50145
File Encoding         : 65001

Date: 2014-03-18 10:17:50
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for tRoleGroup
-- ----------------------------
DROP TABLE IF EXISTS `tRoleGroup`;
CREATE TABLE `tRoleGroup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(16) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ__tRoleGroup__37E53D9E` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;
