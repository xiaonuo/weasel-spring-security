/*
Navicat MySQL Data Transfer

Source Server         : 172.16.0.36
Source Server Version : 50145
Source Host           : 172.16.0.36:3308
Source Database       : costexpressdb

Target Server Type    : MYSQL
Target Server Version : 50145
File Encoding         : 65001

Date: 2014-03-18 10:16:58
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for tMember
-- ----------------------------
DROP TABLE IF EXISTS `tMember`;
CREATE TABLE `tMember` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `MemberID` varchar(50) DEFAULT NULL,
  `PWD` varchar(50) DEFAULT NULL,
  `lockedTime` datetime DEFAULT NULL COMMENT '帐号被锁定有效时间'
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UQ__tMember__73FA27A5` (`MemberID`)
) ENGINE=InnoDB AUTO_INCREMENT=315309 DEFAULT CHARSET=utf8;
