/*
Navicat MySQL Data Transfer

Source Server         : 172.16.0.36
Source Server Version : 50145
Source Host           : 172.16.0.36:3308
Source Database       : costexpressdb

Target Server Type    : MYSQL
Target Server Version : 50145
File Encoding         : 65001

Date: 2014-03-18 10:16:26
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for t_user_auth
-- ----------------------------
DROP TABLE IF EXISTS `t_user_auth`;
CREATE TABLE `t_user_auth` (
  `user_id` int(11) NOT NULL,
  `auth_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`auth_id`),
  KEY `auth_id` (`auth_id`) USING BTREE,
  CONSTRAINT `t_user_auth_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tMember` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `t_user_auth_ibfk_2` FOREIGN KEY (`auth_id`) REFERENCES `tAuthCode` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
